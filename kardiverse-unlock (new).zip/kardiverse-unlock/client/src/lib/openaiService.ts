export interface PrayerResponse {
  prayer: string;
  intention: string;
  category: string;
}

export const OpenAIService = {
  async generatePrayer(intention?: string): Promise<PrayerResponse> {
    try {
      const response = await fetch('/api/generate-prayer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ intention }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate prayer');
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to generate prayer:', error);
      // Fallback prayer
      return {
        prayer: "May peace fill your heart, may wisdom guide your mind, and may love surround you always. In this moment of stillness, find the strength and clarity you seek.",
        intention: intention || "peace and guidance", 
        category: "blessing"
      };
    }
  },

  async generateSongDescription(trackTitle: string): Promise<string> {
    try {
      const response = await fetch('/api/generate-song-description', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ trackTitle }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate song description');
      }

      const data = await response.json();
      return data.description || "A transcendent musical journey designed to elevate the spirit and harmonize the soul.";
    } catch (error) {
      console.error('Failed to generate song description:', error);
      return "A transcendent musical journey designed to elevate the spirit and harmonize the soul.";
    }
  }
};