import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY
});

export interface PrayerResponse {
  prayer: string;
  intention: string;
  category: string;
}

export const OpenAIService = {
  async generatePrayer(intention?: string): Promise<PrayerResponse> {
    try {
      const prompt = intention 
        ? `Generate a meaningful spiritual prayer focused on "${intention}". The prayer should be uplifting, peaceful, and suitable for meditation. Please respond in JSON format with the following structure: {"prayer": "the prayer text", "intention": "the main intention", "category": "type of prayer (e.g., gratitude, healing, guidance)"}`
        : `Generate a meaningful spiritual prayer for general well-being and peace. The prayer should be uplifting, peaceful, and suitable for meditation. Please respond in JSON format with the following structure: {"prayer": "the prayer text", "intention": "the main intention", "category": "type of prayer (e.g., gratitude, healing, guidance)"}`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are a spiritual guide who creates meaningful, peaceful prayers for meditation and reflection. Generate prayers that are universally spiritual without being specific to any particular religion."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        max_tokens: 300,
        temperature: 0.8
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        prayer: result.prayer || "May peace and light guide your path today.",
        intention: result.intention || intention || "general well-being",
        category: result.category || "blessing"
      };
    } catch (error) {
      console.error('Failed to generate prayer:', error);
      // Fallback prayer
      return {
        prayer: "May peace fill your heart, may wisdom guide your mind, and may love surround you always. In this moment of stillness, find the strength and clarity you seek.",
        intention: intention || "peace and guidance", 
        category: "blessing"
      };
    }
  },

  async generateSongDescription(trackTitle: string): Promise<string> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system", 
            content: "You are a spiritual music curator who describes the essence and healing properties of spiritual audio tracks."
          },
          {
            role: "user",
            content: `Describe the spiritual and healing qualities of this audio track: "${trackTitle}". Keep it mystical and inspiring, focusing on how it aids meditation and spiritual elevation.`
          }
        ],
        max_tokens: 150,
        temperature: 0.7
      });

      return response.choices[0].message.content || "A transcendent musical journey designed to elevate the spirit and harmonize the soul.";
    } catch (error) {
      console.error('Failed to generate song description:', error);
      return "A transcendent musical journey designed to elevate the spirit and harmonize the soul.";
    }
  }
};