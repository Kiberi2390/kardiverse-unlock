import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { OpenAIService } from "./openaiService";

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api

  // OpenAI prayer generation endpoint
  app.post('/api/generate-prayer', async (req, res) => {
    try {
      const { intention } = req.body;
      const prayer = await OpenAIService.generatePrayer(intention);
      res.json(prayer);
    } catch (error) {
      console.error('Error generating prayer:', error);
      res.status(500).json({ 
        error: 'Failed to generate prayer',
        prayer: "May peace fill your heart, may wisdom guide your mind, and may love surround you always. In this moment of stillness, find the strength and clarity you seek.",
        intention: intention || "peace and guidance", 
        category: "blessing"
      });
    }
  });

  // OpenAI song description endpoint
  app.post('/api/generate-song-description', async (req, res) => {
    try {
      const { trackTitle } = req.body;
      const description = await OpenAIService.generateSongDescription(trackTitle);
      res.json({ description });
    } catch (error) {
      console.error('Error generating song description:', error);
      res.status(500).json({ 
        description: "A transcendent musical journey designed to elevate the spirit and harmonize the soul."
      });
    }
  });

  // use storage to perform CRUD operations on the storage interface
  // e.g. storage.insertUser(user) or storage.getUserByUsername(username)

  const httpServer = createServer(app);

  return httpServer;
}
