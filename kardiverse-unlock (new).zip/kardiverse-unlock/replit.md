# Kardiverse D6 Room Integration System

## Overview

Kardiverse D6 is a spiritual technology platform that provides AI-powered room integration templates. The system allows users to activate and manage specialized room types (WakeRoom, ZangRoom, BeamerRoom) through activation codes. Each template provides immersive spiritual experiences with customizable audio, visual themes, and interactive components. The application uses a modern full-stack architecture with React frontend, Express backend, and PostgreSQL database integration through Drizzle ORM.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React 18** with TypeScript for the user interface
- **Vite** as the build tool and development server
- **Wouter** for client-side routing instead of React Router
- **TanStack Query** for server state management and API caching
- **shadcn/ui** component library with Radix UI primitives for accessible components
- **Tailwind CSS** for styling with custom Kardiverse theme (deep space/tech colors)
- **Responsive design** with mobile-first approach using custom mobile hooks

### Backend Architecture
- **Express.js** server with TypeScript
- **RESTful API** structure with `/api` prefix for all endpoints
- **Memory storage implementation** with interface for future database migration
- **Middleware stack** includes JSON parsing, URL encoding, and request logging
- **Error handling** with centralized error middleware
- **Development hot reloading** with Vite integration

### Component Architecture
- **Template system** with configurable room types (wake, zang, beamer)
- **Activation system** using localStorage for license management
- **Audio player components** with multiple implementations (basic HTML5 and react-h5-audio-player)
- **Modal system** for activation codes and admin functions
- **Responsive sidebar** navigation with collapsible states

### Data Storage
- **PostgreSQL** configured through Drizzle ORM with Neon Database serverless connection
- **Schema definition** in shared folder for type safety across frontend/backend
- **Migration system** using drizzle-kit for database schema changes
- **Memory storage fallback** for development and testing

### Authentication & Authorization
- **Template activation system** using activation codes stored in localStorage
- **Admin panel** with test activation functionality
- **No user authentication** - system operates on template licensing model

### State Management
- **Local state** with React hooks for component-level state
- **Template activation state** persisted in localStorage
- **Server state** managed through TanStack Query
- **No global state management** - relies on prop drilling and context for shared state

### Audio System
- **Multiple audio player implementations** for cross-browser compatibility
- **Local file upload** support with comprehensive format validation
- **Default template audio** with ability to override with local files
- **Mobile-optimized** audio handling with autoplay detection

### Styling Architecture
- **Custom CSS variables** for consistent theming
- **Kardiverse color palette** with electric blue primary, deep purple secondary, and neon green accent
- **Gradient backgrounds** and glass morphism effects
- **Dark theme** optimized for spiritual/tech aesthetic
- **Component variants** for different states (unlocked, locked, cyber, glass)

## External Dependencies

### Core Framework Dependencies
- **React ecosystem**: react, react-dom, @vitejs/plugin-react
- **Build tools**: vite, typescript, esbuild for production builds
- **Routing**: wouter for lightweight client-side routing

### UI and Styling
- **Component library**: @radix-ui/* primitives for accessibility
- **Styling**: tailwindcss, postcss, autoprefixer
- **Icons**: lucide-react for consistent iconography
- **Utility libraries**: clsx, tailwind-merge, class-variance-authority

### Backend Infrastructure
- **Server**: express with TypeScript support
- **Database**: @neondatabase/serverless for PostgreSQL connection
- **ORM**: drizzle-orm with drizzle-kit for migrations
- **Validation**: zod with drizzle-zod integration

### State and Data Management
- **Server state**: @tanstack/react-query for API state management
- **Form handling**: react-hook-form with @hookform/resolvers
- **Date utilities**: date-fns for date manipulation

### Audio and Media
- **Audio playback**: react-h5-audio-player for enhanced audio controls
- **File handling**: nanoid for unique identifiers

### Development Tools
- **Replit integration**: @replit/vite-plugin-runtime-error-modal, @replit/vite-plugin-cartographer
- **Development server**: tsx for TypeScript execution
- **Session management**: express-session with connect-pg-simple store

### Session Storage
- **PostgreSQL sessions**: connect-pg-simple for production session storage
- **Session configuration**: express-session middleware